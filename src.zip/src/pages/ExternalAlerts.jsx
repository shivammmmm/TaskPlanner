import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Plus, AlertTriangle, MoreHorizontal, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { toast } from '@/components/ui/use-toast';
import PageHeader from '@/components/shared/PageHeader';
import StatusBadge from '@/components/shared/StatusBadge';
import EmptyState from '@/components/shared/EmptyState';

export default function ExternalAlerts() {
  const { employee } = useOutletContext();
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', expiry_date: '', status: 'active' });

  const loadData = async () => { setAlerts(await base44.entities.ExternalAlert.list('-created_date', 200)); setLoading(false); };
  useEffect(() => { loadData(); }, []);

  const handleSave = async () => {
    if (editing) { await base44.entities.ExternalAlert.update(editing.id, form); toast({ title: 'Alert updated' }); }
    else { await base44.entities.ExternalAlert.create(form); toast({ title: 'Alert created' }); }
    setShowForm(false); setEditing(null);
    setForm({ title: '', description: '', priority: 'medium', expiry_date: '', status: 'active' });
    loadData();
  };

  const handleEdit = (a) => { setEditing(a); setForm({ title: a.title || '', description: a.description || '', priority: a.priority || 'medium', expiry_date: a.expiry_date || '', status: a.status || 'active' }); setShowForm(true); };

  return (
    <div>
      <PageHeader title="External Alerts" description="Manage external notifications and alerts"
        actions={<Button onClick={() => { setEditing(null); setForm({ title: '', description: '', priority: 'medium', expiry_date: '', status: 'active' }); setShowForm(true); }} className="bg-blue-600 hover:bg-blue-700"><Plus className="w-4 h-4 mr-1.5" /> New Alert</Button>} />

      {loading ? <div className="bg-white rounded-xl border animate-pulse p-8"><div className="h-12 bg-slate-100 rounded" /></div> : alerts.length === 0 ? (
        <EmptyState icon={AlertTriangle} title="No alerts" description="Create an alert to notify your team" actionLabel="New Alert" onAction={() => setShowForm(true)} />
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {alerts.map(a => (
            <div key={a.id} className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="flex items-start justify-between">
                <h3 className="font-semibold text-slate-900">{a.title}</h3>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="w-4 h-4" /></Button></DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleEdit(a)}><Edit className="w-3.5 h-3.5 mr-2" />Edit</DropdownMenuItem>
                    <DropdownMenuItem onClick={async () => { await base44.entities.ExternalAlert.delete(a.id); loadData(); }} className="text-red-600"><Trash2 className="w-3.5 h-3.5 mr-2" />Delete</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              {a.description && <p className="text-sm text-slate-500 mt-1">{a.description}</p>}
              <div className="flex items-center gap-2 mt-3">
                <StatusBadge status={a.priority} type="priority" />
                <StatusBadge status={a.status} />
                {a.expiry_date && <span className="text-xs text-slate-400">Expires: {a.expiry_date}</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Edit Alert' : 'New Alert'}</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div><Label>Title *</Label><Input value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="mt-1" /></div>
            <div><Label>Description</Label><Textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} className="mt-1" rows={3} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Priority</Label><Select value={form.priority} onValueChange={v => setForm({...form, priority: v})}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="low">Low</SelectItem><SelectItem value="medium">Medium</SelectItem><SelectItem value="high">High</SelectItem><SelectItem value="urgent">Urgent</SelectItem></SelectContent></Select></div>
              <div><Label>Status</Label><Select value={form.status} onValueChange={v => setForm({...form, status: v})}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="active">Active</SelectItem><SelectItem value="resolved">Resolved</SelectItem><SelectItem value="expired">Expired</SelectItem></SelectContent></Select></div>
            </div>
            <div><Label>Expiry Date</Label><Input type="date" value={form.expiry_date} onChange={e => setForm({...form, expiry_date: e.target.value})} className="mt-1" /></div>
            <div className="flex gap-3 pt-2">
              <Button variant="outline" onClick={() => setShowForm(false)} className="flex-1">Cancel</Button>
              <Button onClick={handleSave} disabled={!form.title} className="flex-1 bg-blue-600 hover:bg-blue-700">{editing ? 'Update' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}